#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep  3 13:23:27 2019
@author: gregor
Modified by dliu since 03/31/2022.
"""

import numpy as np
import time
import scipy
import coreEos as eos
from scipy.sparse import csc_matrix
from scipy.sparse.linalg import inv
from scipy.constants import G
from scipy.constants import R as RGas
from globalvar import *
from libCore import *
from solver import *

def shoot_mercmodel(v,ricb,rhocr,rhom,chi_li_in_fix,core_mass_fix,
                    mantle_mass_fix,param,scale):
    
    """ 
    THIS IS SIMILAR TO projects/mercury_interiormodels/shoot_mercmodel_snow.m
    except that we do not use ode45 solver.  Instead, solved by 4th order RK
    using an adaptation of odeRK4sysv (NMM).  This allows the freedom to also
    advance chi_li as a variable of the system.

    Shoots to find one solution from a set of initial conditions 
    specified in the vector v

    Here, the 4 unknowns are 
    1) P(r=0) 2) T(r=0) 3) rcmb 4) rm 5) chiSicb 6) hcr

    The roots of the system are specified by 3 conditions:
        matching P, g at cmb, as well as the melting T at ICB.
        The success is measured in the 3-element vector f

    output: r= radial points of integration (non-dimensional)
         yy(:,1) = pressure vs radius (non-dimensional)
         yy(:,2) = g vs radius (non-dimensional)
         yy(:,3) = temperature vs radius (non-dimensional)
         yy(:,4) = adiabatic temperature vs radius (non-dimensional)
         yy(:,5) = density vs radius (non-dimensional)
         yy(:,6) = chi_li vs radius (non-dimensional)
         # if param['li_el'] == 'S' or 'S+Si', chi_li is chi_li;
         # if param['li_el'] == 'Si', chi_li is ChiSi;
         fout(1) = P at icb (dimensional)
         fout(2) = T at cmb (dimensional)
         fout(3) = Cm/C
         fout(4) = C/MR^2
         fout(5) = xi
         fout(6) = k2
         fout(7) = isnow  (0,1,2 = no, layer, deep snow)
         fout(8) = isnowcmb  (0,1 = snow at CMB (no,yes))
         fout(9) = chi_li_in (initial sulfur content in core)
         fout(10)= gradTa (adiabatic temp gradient at CMB)

     shoot from set of conditions at r=small
     """
    # scales
    a=scale['a']
    ga=scale['ga']
    P=scale['P']
    T=scale['T']    
    
    # Mercury parameters
    M = param['GM']/G
    rm = a*v[3]#param['rm']
    rhomean = 3*M/(4*np.pi*rm**3)
    
    # limits of integration
    r0=0.001 #original code is like this.
    #r0=0.001/a
    rcmb=v[2]
    hcr=v[5]*26e+3

    # calculate Pcmb, gcmb
    rhd=(rm-hcr) # radius of crust-mantle boundary
    rcr=a*rcmb
    Pcmb,gcmb=getPgcmb_crust(rhom,rcr,rhocr,rhd,rm,M,param,scale)
    Pcmb=Pcmb/P
    gcmb=gcmb/ga

    # get gruneisan, bulk and density for P,T at r0 
    P1=P*v[0]
    T1=v[1]*T

    # 20220302. Replace the following lines with the new function eosInnerCore.
    #if param['li_el'] =='S':
    #    rho = eos.solidFccFe(P1/1E+9,T1,param)[1]
    #elif param['li_el'] == 'Si':
    #    rho = eos.solidFccFeSi(chi_li_icb, P1/1E+9, T1, param)[1]
    #elif param['li_el'] == 'S+Si':
    #    rho = eos.solidFccFeSi(chi_Si_icb, P1/1E+9, T1, param)[1]
    if param['li_el'] == 'Si':
        chi_icb = {'Si':v[4], 'S':0}
    elif param['li_el'] == 'S':
        chi_icb = {'Si':0, 'S':v[4]}
    elif param['li_el'] == 'S+Si':
        chi_icb = {'Si':chi_Si_icb, 'S':v[4]}
    rho = eos.eosInnerCore(chi_icb,P1/1E+9,T1,param)[1]
  
    #boundary values at r0 for integration
    gr0=4*np.pi*G*rho*(r0*a)/(3*ga)
    # initial P, gr0, T to integrate from core to inner core boundary.    
    y0 = [v[0], gr0, T1/T]

    #Shoot In solid inner core 
    sol = scipy.integrate.solve_ivp(lambda t,y: rhs_PTrhog_solid_snow(chi_icb, t,y,ricb,scale,param),
                                    [r0, ricb], y0, method='LSODA',
                                    rtol=5e-5)
    # return radius array to rs.
    # return solution at each rs to ys.
    rs = sol.t
    ys = sol.y
    ns=len(rs)
    
    # calculate melting temperature at ICB
    chi_li_icb=v[4]
    P1=P*ys[0,-1]
    #Tmicb = getmelt_anzellini(chiSicb,P1,param,0)/T
    # Use the new getCoreLiquidus function.
    Tmicb = getCoreLiquidus(chi_li_icb,chi_Si_icb,P1,param,0)/T

    # boundary values for FOC integration: 
    # continuity of P, g, and T=Tm
    yicb = [ys[0,-1],ys[1,-1],Tmicb,Tmicb]

    # Shoot In Fluid core
    nc=51
    h=(rcmb-ricb)/(nc-1)
    rc,yc,rhof,chi_li = odeRK4_snow('rhs_fluid_snow',ricb,rcmb,h,yicb,chi_li_icb,
                                  scale,param)
    # Calculate moments of inertia:
    # First build polynomials of density
    rhos = np.empty(ns)
    #if param['li_el'] == 'S':
    #    for i in range(0,ns):
    #        rhos[i]=eos.solidFccFe(P*ys[0,i]/1E+9,T*ys[2,i],param)[1]/rhomean
    #elif param['li_el'] == 'Si':
    #    for i in range(0,ns):
    #        rhos[i]=eos.solidFccFeSi(chiS[0],P*ys[0,i]/1E+9,T*ys[2,i],param)[1]/rhomean
    if param['li_el'] == 'Si':
        chi_icb = {'Si':chi_li[0], 'S':0}
    elif param['li_el'] == 'S':
        chi_icb = {'Si':0, 'S':chi_li[0]}
    elif param['li_el'] == 'S+Si':
        chi_icb = {'Si':chi_Si_icb, 'S':chi_li[0]}
        
    for i in range(0,ns):
        rhos[i]=eos.eosInnerCore(chi_icb,P*ys[0,i]/1E+9, T*ys[2,i], param)[1]/rhomean
        
    #bigCm = 0.2*rhocr*(1-rh**5)/rhomean + 0.2*rhom*(rh**5-rcmb**5)/rhomean
    #bigIo = bigIo + bigCm   # To get dimensional moment of inertia, * 8pi/3*rhomean*a^5
    #CmC=bigCm/bigIo # Cm/C 
    #CMR2=2*bigIo # C/MR^2 
    #CmCtry=bigCm/bigIo #Cm/C 
    #CMR2try=2*bigIo #C/MR^2 

    # calculate initial sulfur
    chisrc2=chi_li*rc**2
    chi_li_in = 3/(rcmb**3)*simpsonDat(rc,chisrc2)
    
    # snow state
    isnow=0  # snow index: default is no snow
    
    if ((chi_li[-1]-chi_li_icb) > 1e-10):
        isnow=1
        # get dimensional P and T at second point in FOC
        i=0
        T1=T*yc[i,2]
        P1=P*yc[i,0]
        Tm=getCoreLiquidus(chi_li[i], chi_Si_icb, P1,param,0)  # get Tliquidus

        if abs(T1-Tm)<1e-8: # if adiabat temperature = Liquidus 
            isnow=2    
  
    isnowcmb=0;  # snow at cmb index: default no
    if isnow==1 or isnow==2:
        i=-1
        # get dimensional P and T
        T1=T*yc[i,2]
        P1=P*yc[i,0]
        Tm=getCoreLiquidus(chi_li[i],chi_Si_icb, P1,param,0)  # get Tliquidus

        if abs(T1-Tm)<1e-6:  #if adiabat temperature = Liquidus
            isnowcmb=1
    
    # Calculate k2_h and xi_h
  
    # avg inner core, outer core densities
    #rhor2=np.convolve(sols,[1,0,0])
 
    # Calculate k2 and xi
    #rhoml=rhom/rhomean

    #k2,xi=getk2(ricb,rcmb,rhoml,rm,sols,solf,param,scale)
        
    # adiabatic temp gradient at CMB
    gradTa=T/a*(yc[nc-1,3]-yc[nc-2,3])/(rc[nc-1]-rc[nc-2])
    fout=[P*ys[0,-1],T*yc[nc-1,2],isnow,isnowcmb,chi_li_in,gradTa]

    r=np.concatenate((rs,rc))
    rho = np.concatenate((rhos*rhomean,rhof))
    # include the (1+xi) factor on Cm/C
    #CmCtry = CmCtry*(1+xi)
    core_mass = get_mass_core(r*a,rho)
    # function to minimize (roots)
    f=[yc[-1,0]-Pcmb,  # match P at cmb
       yc[-1,1]-gcmb,  # match g at cmb
       ys[2,-1]-Tmicb, # match Tm at icb
       (core_mass-core_mass_fix)/M,
       (mantle_mass_fix-get_mass_mantle(rcr,rm-hcr,rhom))/mantle_mass_fix,
       chi_li_in_fix-chi_li_in] # the last two lines are different from the presentDay model.

    # concatenate solution    

    ytemp=np.vstack((ys,ys[2]))
    y = np.hstack((ytemp,np.transpose(yc)))
    chi = np.concatenate((np.zeros(ns),chi_li))
    if param['li_el']=='Si': 
        chi[0:ns] = chi_li[0]    
    yy=np.vstack((y[0],y[1],y[2],y[3],rho/rhomean,chi))
    
    return f,r,yy,fout,ricb*a,rhomean,rm,hcr

def mynewtonSys(Jfun,x0,varargin,
                xtol=5e-5,ftol=5e-5,maxit=15,verbose=False):
    """
     newtonSys  Newton's method for systems of nonlinear equations.
    
     Synopsis:  x = newtonSys(Jfun,x0)
                x = newtonSys(Jfun,x0,xtol)
                x = newtonSys(Jfun,x0,xtol,ftol)
                x = newtonSys(Jfun,x0,xtol,ftol,maxit,verbose)
                x = newtonSys(Jfun,x0,xtol,ftol,maxit,verbose,arg1,arg2,...)
    
     Input:  Jfun = (string) name of mfile that returns matrix J and vector f
             x0   = initial guess at solution vector, x
             xtol = (optional) tolerance on norm(dx).  Default: xtol=5e-5
             ftol = (optional) tolerance on norm(f).   Default: ftol=5e-5
    
             verbose = (optional) flag.  Default: verbose=0, no printing.
             arg1,arg2,... = (optional) optional arguments that are passed                   
             through to the mfile defined by the 'Jfun' argument
    
     Note:  Use [] to request default value of an optional input.  For example,
            x = newtonSys('JFun',x0,[],[],[],arg1,arg2) passes arg1 and arg2 to
            'JFun', while using the default values for xtol, ftol, and verbose
    
     Output:  x = solution vector;  x is returned after k iterations if 
                  tolerances are met, or after maxit iterations if 
                  tolerances are not met.
    """

    
    xeps = xtol
    feps = ftol #   %  Smallest tols are 5*eps

    if verbose:
        print('\nNewton iterations\n  k     norm(f)      norm(dx)    time(s)\n')

    if Jfun == 'J_mercmodel_nosic': x0.pop(1)
    x = x0
    k = 0        #  Initial guess and current number of iterations
    
    
    while k <= maxit:
      start = time.time()
      k = k + 1
      J,f = eval(Jfun)(x,varargin)   #   Returns Jacobian matrix and f vector
      dx = np.dot(np.linalg.inv(J),f)
      x = x - dx
      if verbose:     
          end = time.time()
          print(k,np.linalg.norm(f),np.linalg.norm(dx),end-start)
      if (np.linalg.norm(f) < feps) or (np.linalg.norm(dx) < xeps):
          return x

    print('Solution not found within tolerance after_',k,'_iterations\n')
    print('Exiting the code')
    sys.exit()
	
def J_mercmodel(v,args):
    """
      computes the Jacobian and function evaluation for our 
      interior model system
    
     input vinit = variable vinit (5 element vector)
    
     output f = function evaluation (5 function)
            J = Jacobian matrix of derivatives
    """

    #initialize
    ricb,rhocr,rhom,chi_li_in_fix,core_mass,mantle_mass,param,scale = args
    n=len(v)
    f = np.zeros(n) # f must be defined as a column vector
    f2 = np.zeros(n) # f must be defined as a column vector
    J = np.zeros((n,n))  
    
    # compute the function f, 
    f=shoot_mercmodel(v,ricb,rhocr,rhom,chi_li_in_fix,core_mass,mantle_mass,
                      param,scale)[0]

    eps=1.e-6
    for j in range(n):
        temp=v[j]
        h=eps*abs(temp)
        if (h==0):
            h=eps
        v[j]=temp+h
        h=v[j]-temp
        f2=shoot_mercmodel(v,ricb,rhocr,rhom,chi_li_in_fix,core_mass,
                           mantle_mass,param,scale)[0]
        v[j]=temp
        for i in range(n):
            J[i,j]=(f2[i]-f[i])/h

    return J,f

def getPgcmb_crust(rhom,rc,rhocr,rh,rm,M,param,scale):
    """
    determines the Pressure and grav acc at cmb for a given choice of 
    mantle density (rhom), cmb radius (rcmb)
    crustal density (rhocr), crust-mantle boundary radius (rh)
    """
    # Mercury parameters
    #GM=param['GM']
    #M=GM/G
    #rm = param['rm']

    # scales
    a=scale['a']
    P=scale['P']

    # mass of crust
    Mh=4*np.pi*rhocr*(rm**3-rh**3)/3
    # mass of mantle
    Mm=4*np.pi*rhom*(rh**3-rc**3)/3
    # mass of core
    Mcore=M-Mm-Mh
    # grav acc at CMB
    gcmb=Mcore*G/rc**2

    # Pressure at CMB: Shoot In crust + mantle 
    y0 = [0,1]
    sol = scipy.integrate.solve_ivp(lambda t,y: rhs_Pgz(t,y,rhocr,scale), [1,rh/a],
                                    y0, method='RK45')

    yh = sol.y[:,-1]

    sol = scipy.integrate.solve_ivp(lambda t,y: rhs_Pgz(t,y,rhom,scale), 
                                    [rh/a,rc/a],
                                    yh, method='RK45')

    Pcmb=P*sol.y[0,-1] # dimensional

    return Pcmb,gcmb


def getchi_li_grun(yT,yP,chi_li_old,scale,param):
    # scales
    P=scale['P']
    T=scale['T']  
    el = param['li_el']  
    
    chitmp = np.zeros(2)
    # get dimensional P and T
    T1=T*yT
    P1=P*yP
    # chiSold
    #Tm=getmelt_anzellini(chiSold,P1,param,0)
    Tm=getCoreLiquidus(chi_li_old, chi_Si_icb, P1,param,0)

    if T1>Tm: # if adiabat temperature larger than Liquidus
        # get chiS on basis of previous radius         
        chi_li=chi_li_old
    else:
        # get chiS that matches melting
        chi_li_eut=0.11+0.187*np.exp(-0.065*P1*1e-9)
        sol = scipy.optimize.root(getCoreLiquidus, chi_li_old, 
                                  tol=1e-6, args=(chi_Si_icb, P1, param, T1))  
        chi_li = min(sol.x[0],chi_li_eut)
    

    # Updated Equation of State from Rivoldini
    if el == 'S': 
        out = eos.liquidNonIdalFeS(chi_li,P1/1E+9,T1,param)
    elif el == 'Si':
        out = eos.liquidNonIdalFeSi(chi_li,P1/1E+9,T1,param)
    # added by DL on 02/15/2022.
    elif el == 'S+Si':
        chitmp[0] = chi_li
        chitmp[1] = chi_Si_icb
        out = eos.liquidNonIdalFeSSi(chitmp,P1/1E+9,T1,param)
    else:
        print('WARNING: invalid light element')    
    rho = out[1]
    KS = out[4]*1E+9
    grun = out[6]
    
    return chi_li,rho,grun,KS



def CvC(theta_T):
    # heat capacity at constant volume, T and theta in K
    f=3*RGas*(4*debye3(theta_T)-theta_T*3/(np.exp(theta_T)-1))
    return f


def debye3(x, maxdeg=7): # truncated to save computation time
    """
    %DEBYE3 ThirdF order Debye function.
    %   Y = DEBYE3(X) returns the third order Debye function, evaluated at X.
    %   X is a scalar.  For positive X, this is defined as
    %
    %      (3/x^3) * integral from 0 to x of (t^3/(exp(t)-1)) dt
    
    %   Based on the FORTRAN implementation of this function available in the
    %   MISCFUN Package written by Alan MacLead, available as TOMS Algorithm 757
    %   in ACM Transactions of Mathematical Software (1996), 22(3):288-301.
    """

    adeb3=[2.70773706832744094526,
           0.34006813521109175100,
           -0.1294515018444086863e-1,
           0.79637553801738164e-3,
           -0.5463600095908238e-4,
           0.392430195988049e-5,
           -0.28940328235386e-6,
           0.2173176139625e-7,
           -0.165420999498e-8,
           0.12727961892e-9,
           -0.987963459e-11,
           0.77250740e-12,
           -0.6077972e-13,
           0.480759e-14,
           -0.38204e-15,
           0.3048e-16,
           -0.244e-17,
           0.20e-18,
           -0.2e-19]

    if x < 0: 
        print('error in debye3: negative input value')
        return 0
    elif (x < 3.e-8): 
        print('low input value in debye3: check input value')
        D3 = ((x - 7.5 ) * x + 20.0)/20.0
    elif x <= 4:
        # routine only accurate within these limits
        # but should be OK for typical x values in our
        # models

        t = ((x**2/8)-0.5)-0.5
        D3 = cheval(adeb3[0:maxdeg],t)-0.375*x
    else:
        print('error in debye3: input value should be smaller than 4');
        return 0

    return D3

def cheval(a, t):
    """
    CHEVAL evaluates a Chebyshev series.
    modified by MD for Matlab 
    
      Discussion:
    
        This function evaluates a Chebyshev series, using the
        Clenshaw method with Reinsch modification, as analysed
        in the paper by Oliver.
    
      Author:
    
        Allan McLeod,
        Department of Mathematics and Statistics,
        Paisley University, High Street, Paisley, Scotland, PA12BE
        macl_ms0@paisley.ac.uk
    
      Reference:
    
        Allan McLeod,
        Algorithm 757, MISCFUN: A software package to compute uncommon
          special functions,
        ACM Transactions on Mathematical Software,
        Volume 22, Number 3, September 1996, pages 288-301.
    
        J Oliver,
        An error analysis of the modified Clenshaw method for
        evaluating Chebyshev and Fourier series,
        Journal of the IMA,
        Volume 20, 1977, pages 379-391.
    
      Parameters:
    
        Input, A(1:N), the coefficients of the Chebyshev series.
    
        Input,  T, the value at which the series is
        to be evaluated.
    
        Output, CHEV, the value of the Chebyshev series at T.
    
    """
    n=len(a)-1
    u1 = 0.0
    #  T <= -0.6, Reinsch modification.
    # -0.6 < T < 0.6, Standard Clenshaw method.
    #  T > 0.6 Reinsch
    if t <= -0.6 or t>=0.6:
        d1 = 0.0
        tt = (t+0.5) + 0.5
        tt = tt+tt
        for i in range(n,-1,-1):
            d2 = d1
            u2 = u1
            d1 = tt * u2 + a[i] - d2
            u1 = d1 - u2
        chev = 0.5*( d1-d2 )


    else:
        u0 = 0.0
        tt = t + t
        for i in range(n,-1,-1):
            u2 = u1
            u1 = u0
            u0 = tt * u1 + a[i] - u2

        chev = 0.5*( u0 - u2 ) 

    return chev

def Eth(T,theta):
    #internal thermal energy (without not relevant term linear in theta),
    # T and theta in K
    RGas=8.3144621
    f=3.*RGas*(3*theta/8 + T*debye3(theta/T))
    
    return f

def gammaC(eta,gamma0,q0):
    # Grueneisen parameter
    # eta=V0/V
    return gamma0*eta**(-q0)

def thetaC(eta,theta0,gamma0,q0):
    # Debye temperature, eta=V0/V
    return theta0*np.exp((gamma0-gammaC(eta,gamma0,q0))/q0)




#### The k2 stuff ####
    
def getk2(rs,rf,rhoml,rhos,rhof,rm,param,scale):
    """
    %
    % Calculates k2, xi = [(Bs-As) - (Bs'-As')]/ (Bmf -Amf)
    % for given density structure of mercury and c22
    %
    %
    """
    # Mercury parameters
    M=param['GM']/G
    #rm = param['rm']
    rhomean = 3*M/(4*np.pi*rm**3)
    c22=param['c22']

    # scales
    a=scale['a']
    ga=scale['ga']

    bigGscale=ga/(rhomean*a)
    bigGnd=G/bigGscale

    # Define radial grid points
    nr=400
    nrs=int(round(nr*(rs/rf)))
    nrf=nr-nrs
    
    r = np.empty(nr)
    rho = np.empty(nr)
    g = np.empty(nr)
    
    for k in range(nrs):
        r[k]=rs*(k+1)/nrs


    for k in range(nrf):
        r[k+nrs]=rs+(rf-rs)*k/nrf
    
    drf=(rf-rs)/nrf

    # Build density (rho) and gravitational acceleration (g)
    f4piG=4*np.pi*bigGnd/3

    #  in inner core
    avgr=0.5*r[0]
    rho[0]=np.polyval(rhos, avgr)
    g[0]=f4piG*rho[0]*r[0]
  
    for k in range(1,nrs):
        avgr=0.5*(r[k]+r[k-1])
        rho[k]=np.polyval(rhos, avgr)
        g[k]= f4piG*rho[k]*(r[k]**3-r[k-1]**3)/r[k]**2 +  g[k-1]*(r[k-1]/r[k])**2
    
    #  in fluid core
    avgr=r[nrs]+0.5*drf
    rho[1+nrs]=np.polyval(rhof, avgr)
    g[1+nrs]=f4piG*rho[1+nrs]*(r[1+nrs]**3-r[nrs]**3)/r[1+nrs]**2\
             +g[nrs]*(r[nrs]/r[1+nrs])**2
             
    for k in range(0,nrf):
        avgr=0.5*(r[k+nrs]+r[k+nrs-1])
        rho[k+nrs]=np.polyval(rhof, avgr)
        g[k+nrs]=f4piG*rho[k+nrs]*(r[k+nrs]**3-r[k+nrs-1]**3)/r[k+nrs]**2\
                 +g[k+nrs-1]*(r[k+nrs-1]/r[k+nrs])**2

    # solution
    pot = getpotvsr(nr,bigGnd,r,rho,g)
    k2 = pot[-1]-1;
    
    # get ellipticity
    fell=1.0
    drhocmb = rho[-1]-rhoml
    ell = c22*10.0/ (rhoml*(1 + k2*rf**5)+ fell*(1+k2)*drhocmb*rf**5)
    # calculate Bs-As
    factrho=rhoml+fell*drhocmb
    BsAs=0

    for k in range(nrs):
        BsAs=BsAs+(4*np.pi/5)*bigGnd*rf*rf*(rho[k]-rho[k+1])*(r[k]**4)*pot[k]/g[k]

    BsAs=BsAs*(8*np.pi/15)*ell*factrho

    # calculate Bmf-Amf
    sum3=0
    for k in range(nrs,nr-1):
        sum3=sum3+(4*np.pi/5)*bigGnd*rf*rf*(rho[k]-rho[k+1])*(r[k]**4)*pot[k]/g[k]

    ffrho=rhoml + fell*drhocmb*rf**5
    BmAm=(8*np.pi/15)*ell*(ffrho+sum3*factrho)

    # calculate xi
    xi=BsAs/BmAm

    return k2,xi


def get_mass_mantle(rcmb,rmantle,rhom):
    return rhom*(rmantle**3-rcmb**3)



# Moved to the end.
def shoot_mercmodel_nosic(v,Tctrplus,rhocr,rhom,chi_li_in_fix,core_mass_fix,
                    mantle_mass_fix,param,scale):   
    """ 
    THIS IS SIMILAR TO projects/mercury_interiormodels/shoot_mercmodel_snow.m
    except that we do not use ode45 solver.  Instead, solved by 4th order RK
    using an adaptation of odeRK4sysv (NMM).  This allows the freedom to also
    advance chiS as a variable of the system.

    Shoots to find one solution from a set of initial conditions 
    specified in the vector v

    Here, the 5 unknowns are 
    1) P(r=0) 2) rcmb 3) rm 4) chiSctr 5) hcr

    The roots of the system are specified by 2 conditions:
        matching P, g at cmb.
        The success is measured in the 2-element vector f

    output: r = radial points of integration (non-dimensional)
         yy(:,1) = pressure vs radius (non-dimensional)
         yy(:,2) = g vs radius (non-dimensional)
         yy(:,3) = temperature vs radius (non-dimensional)
         yy(:,4) = adiabatic temperature vs radius (non-dimensional)
         yy(:,5) = density vs radius (non-dimensional)
         yy(:,6) = chiS vs radius (non-dimensional)
         fout(1) = P at icb (dimensional)
         fout(2) = T at cmb (dimensional)
         fout(3) = Cm/C
         fout(4) = C/MR^2
         fout(5) = xi
         fout(6) = k2
         fout(7) = isnow  (0,1,2 = no, layer, deep snow)
         fout(8) = isnowcmb  (0,1 = snow at CMB (no,yes))
         fout(9) = chi_li_in (initial light (sulfur/silicon) content in core)
         fout(10)= gradTa (adiabatic temp gradient at CMB)

     shoot from set of conditions at r=small
     """

    # scales
    a=scale['a']
    ga=scale['ga']
    P=scale['P']
    T=scale['T']
    
    # Mercury parameters
    M = param['GM']/G
    rm = a*v[2]
    rhomean = 3*M/(4*np.pi*rm**3)

    # limits of integration
    r0=0.001
    rcmb=v[1]
    hcr=v[4]*26e+3
    
    # calculate Pcmb, gcmb
    rhd=(rm-hcr) # radius of crust-mantle boundary
    rcr=a*rcmb
    Pcmb,gcmb=getPgcmb_crust(rhom,rcr,rhocr,rhd,rm,M,param,scale)
    Pcmb=Pcmb/P
    gcmb=gcmb/ga

    # get gruneisan, bulk and density for P,T at r0 
    P1=P*v[0]
    chi_li_ctr=v[3]
    #??Should I use the new getCoreLiquidus? 
    Tmctr = getmelt_anzellini(chi_li_ctr,P1,param,0) 
    #Tmctr = getCoreLiquidus(chi_li_ctr,chi_Si_icb,P1,param,0)/T    
    # Temperature at center is Tmelt + Tcplus
    T1=(Tmctr+Tctrplus)
    
    # get density for P,T at center
    rho = eos.liquidNonIdalFeS(chi_li_ctr,P1/1E+9,T1,param)[1]
    
    # boundary values at r0 for integration
    gr0=4*np.pi*G*rho*(r0*a)/(3*ga)
    y0 = [v[0], gr0, T1/T, T1/T]

    # Shoot In Fluid core
    nc=101
    h=(rcmb-r0)/(nc-1)
    rc,yc,rhof,chi_li = odeRK4_snow('rhs_fluid_snow',r0,rcmb,h,y0,chi_li_ctr,
                                  scale,param)

    # Calculate moments of inertia:
    # First build polynomials of density
    for i in range(0,nc):
        rhof[i]=rhof[i]/rhomean

    #solf=np.polyfit(rc,rhof,3)
    
    # ... then multiply by r4 and integrate
    #rhor4=np.convolve(solf,[1,0,0,0,0])
    #bigIo=np.polyval(np.polyint(rhor4),rcmb)

    #bigCm = 0.2*rhocr*(1-rh**5)/rhomean + 0.2*rhom*(rh**5-rcmb**5)/rhomean
    #bigIo = bigIo + bigCm   # To get dimensional moment of inertia, * 8pi/3*rhomean*a^5
    #CmC=bigCm/bigIo # Cm/C 
    #CMR2=2*bigIo # C/MR^2 
 
    # calculate initial sulfur
    chisrc2=chi_li*rc**2
    chi_li_in = 3/(rcmb**3)*simpsonDat(rc,chisrc2)

    rlow=rcmb*a
    for i in range(nc):
        if chi_li[i]>chi_li_ctr:
            slope=(chi_li[i+1]-chi_li[i])/(rc[i+1]-rc[i])
            rlow=(rc[i]+(chi_li_ctr-chi_li[i])/slope)
            rlow=a*rlow
            break
    
    # snow state
    isnow=0  # snow index: default is no snow
    
    if ((chi_li[-1]-chi_li_ctr) > 1e-10):
        isnow=1  
  
    isnowcmb=0;  # snow at cmb index: default no
    if isnow==1 or isnow==2:
        i=-1
        # get dimensional P and T
        T1=T*yc[i,2]
        P1=P*yc[i,0]
        Tm = getCoreLiquidus(chi_li[i],chi_Si_icb, P1,param,0) # get Tliquidus

        if abs(T1-Tm)<1e-6:  #if adiabat temperature = Liquidus
            isnowcmb=1
    
    # Calculate k2_h and xi_h
  
    # avg inner core, outer core densities
    #rhor2=np.convolve(sols,[1,0,0])
 
    # Calculate k2 and xi
    #rhoml=rhom/rhomean

    #k2,xi=getk2(ricb,rcmb,rhoml,rm,sols,solf,param,scale)

        
    # adiabatic temp gradient at CMB
    gradTa=T/a*(yc[nc-1,3]-yc[nc-2,3])/(rc[nc-1]-rc[nc-2])
    fout=[rlow,T*yc[-1,2],isnow,isnowcmb,chi_li_in,gradTa]
    # include the (1+xi) factor on Cm/C
    #CmCtry = CmCtry*(1+xi)
    core_mass = get_mass_core(rc*a,rhof*rhomean)
    # function to minimize (roots)
    f=[yc[-1,0]-Pcmb,  # match P at cmb
       yc[-1,1]-gcmb,  # match g at cmb
       (core_mass-core_mass_fix)/M,
       (mantle_mass_fix-get_mass_mantle(rcr,rm-hcr,rhom))/mantle_mass_fix,
       chi_li_in-chi_li_in_fix]

    # concatenate solution
    r=np.array(rc)
    yy=np.vstack((yc[:,0], yc[:,1], yc[:,2], yc[:,3], rhof, chi_li))    
    
    return f,r,yy,fout,0,rhomean,rm,hcr

def J_mercmodel_nosic(v,args):
    """
      computes the Jacobian and function evaluation for our 
      interior model system
    
     input vinit = variable vinit (5 element vector)
    
     output f = function evaluation (5 function)
            J = Jacobian matrix of derivatives
    """

    #initialize
    ricb,rhocr,rhom,chi_li_in_fix,core_mass,mantle_mass,param,scale = args
    n=len(v)
    f = np.zeros(n) # f must be defined as a column vector
    f2 = np.zeros(n) # f must be defined as a column vector
    J = np.zeros((n,n))  
    
    # compute the function f, 
    f=shoot_mercmodel_nosic(v,ricb,rhocr,rhom,chi_li_in_fix,core_mass,mantle_mass,
                      param,scale)[0]

    eps=1.e-6
    for j in range(n):
        temp=v[j]
        h=eps*abs(temp)
        if (h==0):
            h=eps
        v[j]=temp+h
        h=v[j]-temp
        f2=shoot_mercmodel_nosic(v,ricb,rhocr,rhom,chi_li_in_fix,core_mass,
                           mantle_mass,param,scale)[0]
        v[j]=temp
        for i in range(n):
            J[i,j]=(f2[i]-f[i])/h

    return J,f