# libCore.py is part of the software Mercury_present_evolution.
# It contains common functions used by the presentDay and evolution model.
import numpy as np
import time
import scipy
import coreEos as eos
from scipy.sparse import csc_matrix
from scipy.sparse.linalg import inv
from scipy.constants import G
from scipy.constants import R as RGas
from globalvar import *

# Added by Tilio. 20220614.
TmFeS=eos.meltingDataFromFile("TmFeSmelt.dat")
def TmFeSSi(xS,xSi,p):
    p1=p*1e-9 
    TmFe= 495.4969600595926*(22.19 + p1)**0.42016806722689076   # Fe liquidus Anzellini et al. 2013
    deltaTS=TmFeS(0,p1)-TmFeS(xS,p1)
    TSiEut=1538*(1.+0.040551*p1)**0.4608294930875576 # Fe-rich eutectic melting T of Fe-Si Edmund et al 2022
    xSiEut=0.12 # assumed constant for p range of Mercury, Edmund et al 2022
    deltaTSi=(TmFe-TSiEut)*xSi/xSiEut
    return TmFe-deltaTS-deltaTSi
	
def getCoreLiquidus(el1,el2,P,param,To):
	# getCoreLuquidus calculates the melting temperature of the core
	# 	given the wt% of light elements and pressure. 
	# It calls for function eos.liquidusFeSSi.
	
    # AR: new compact formulation old one not correct
    # el1 is wt of S and el2 is wt of Si, P in Pa
    # why fo we need To
    # this is ultra ugli! for all cases el1 shoud be S and el2 Si
    # or use a dictionary
	
    # What's To? Since To is mostly zero, the return for 'S'/'Si' is simply Tm.
    # The function simply calculates the melting temperature given P and wt% of light elements.
    
    # el1 and el2 are wt% of S and Si, respectively. 
    el = param['li_el']
    if el == 'S':
        xS = el1
        xSi = 0
    elif el == 'Si':
        xS = 0
        xSi = el2
    elif el == 'S+Si':
        xS = el1
        xSi = el2
		
    Tm=eos.liquidusFeSSi(xS,xSi,P)
    Tm=param['liquidus'](xS,xSi,P)
    return Tm-To

def getchi_li_grun(yT,yP,chi_li_old,scale,param):
# AR:what does this do?
    # scales
    P=scale['P']
    T=scale['T']  
    el = param['li_el']
    
    chitmp = np.zeros(2)
    # get dimensional P and T
    T1=T*yT
    P1=P*yP
    # chi_li_old
    #AR: how does the line below know about  chi_Si_icb??
    Tm=getCoreLiquidus(chi_li_old, chi_Si_icb, P1,param,0)

    if T1>Tm: # if adiabat temperature larger than Liquidus
        # get chi_li on basis of previous radius         
        chi_li=chi_li_old
    else:
        # get chi_li that matches melting
        chi_li_eut=0.11+0.187*np.exp(-0.065*P1*1e-9) #AR this braket is only of for Fe-S should be differen for Fe-Si and Fe-S-Si
        # AR better use a lambda function for gerCoreLiquidus like: lambda x: getCoreLiquidus(x,xSi,P1) for Fe-S and Fe-S-Si and lambda x: getCoreLiquidus(xS,x,P1)
        sol = scipy.optimize.root(getCoreLiquidus, chi_li_old,
                                  tol=1e-6, args=(chi_Si_icb, P1, param, T1))          
        chi_li = min(sol.x[0],chi_li_eut)    

    # Updated Equation of State from Rivoldini
#AR
    # should only be this line and remove chitmp
    #out = eos.liquidNonIdalFeSSi([chi_li, chi_Si_icb],P1/1E+9,T1,param)
    if el == 'S': 
        out = eos.liquidNonIdalFeS(chi_li,P1/1E+9,T1,param)
    elif el == 'Si':
        out = eos.liquidNonIdalFeSi(chi_li,P1/1E+9,T1,param)
	# added by DL on 02/15/2022.
    elif el == 'S+Si':
        chitmp[0] = chi_li
        chitmp[1] = chi_Si_icb
        out = eos.liquidNonIdalFeSSi(chitmp,P1/1E+9,T1,param)
    else:
        print('WARNING: invalid light element')#AR: stop code if this occurs
    rho = out[1]
    KS = out[4]*1E+9
    grun = out[6]
    return chi_li,rho,grun,KS
	
def getpotvsr(nr,bigGnd,rnd,rhond,gnd):
    # This function calculates the total potential vs radius in core

    l=2 # %spherical harmonic degree

    # build matrix A (sparse) element by element
    # specifying row, column and numerical value of all non-zero

    ndim=2*nr-1
    k=0
  
    row = np.zeros(3191, dtype=int)
    col = np.zeros(3191, dtype=int)
    s = np.zeros(3191)
    
    kk=0
    row[kk]=k
    col[kk]=k
    s[kk]=rnd[0]**(2*l+1)
  
    kk=kk+1
    row[kk]=k
    col[kk]=k+1
    s[kk]=-1
    
    kk=kk+1
    row[kk]=k
    col[kk]=k+2
    s[kk]=-rnd[0]**(2*l+1)

    alpha = 4.0*np.pi*bigGnd*rnd[0]*(rhond[0]-rhond[1])/gnd[0]

    kk=kk+1
    row[kk]=k+1
    col[kk]=k
    s[kk]=(l - alpha)*rnd[0]**(2*l+1)

    kk=kk+1
    row[kk]=k+1
    col[kk]=k+1
    s[kk]=l+1

    kk=kk+1
    row[kk]=k+1
    col[kk]=k+2
    s[kk]=-l*rnd[0]**(2*l+1)

    for j in range(1,nr-1):
    
        k=2*(j+1)-2
        
        kk=kk+1
        row[kk]=k
        col[kk]=k
        s[kk]=rnd[j]**(2*l+1)

        kk=kk+1
        row[kk]=k
        col[kk]=k-1
        s[kk]=1

        kk=kk+1
        row[kk]=k
        col[kk]=k+1
        s[kk]=-1
    
        kk=kk+1
        row[kk]=k
        col[kk]=k+2
        s[kk]=-rnd[j]**(2*l+1)
        
        alpha = 4.0*np.pi*bigGnd*rnd[j]*(rhond[j]-rhond[j+1])/gnd[j]

        kk=kk+1
        row[kk]=k+1
        col[kk]=k-1
        s[kk]=-(l+1 + alpha)
    
        kk=kk+1
        row[kk]=k+1
        col[kk]=k
        s[kk]=(l - alpha)*rnd[j]**(2*l+1)
    
        kk=kk+1
        row[kk]=k+1
        col[kk]=k+1
        s[kk]=l+1
    
        kk=kk+1
        row[kk]=k+1
        col[kk]=k+2
        s[kk]=-l*rnd[j]**(2*l+1)

    k=2*nr-2
    kk=kk+1
    row[kk]=k
    col[kk]=k
    s[kk]=rnd[nr-1]**l

    # build sparse matrix A
    A=np.zeros([ndim, ndim])
    A[row,col] = s

    #A = np.array(row,col,s,ndim,ndim)

    rhs=np.zeros(2*nr-1)
    rhs[2*nr-2]=1.0

    A = csc_matrix(A)
    #print(A)
    b = inv(A)*rhs

    # solution
    pot = np.empty(nr)
    pot[0]=b[0]*rnd[0]**l
    
    for k in range(1,nr):
        kk=2*(k+1)-2
        pot[k]=b[kk]*rnd[k]**l + b[kk-1]*rnd[k]**(-l-1)

    return pot

def get_mass_norm(r,rho,rho_mean):
    ssum = rho[0]/rho_mean*r[0]**3/r[-1]**3
    for i in range(1,len(r)):
        ssum = ssum + rho[i]/rho_mean*(r[i]**3/r[-1]**3-r[i-1]**3/r[-1]**3)
    return ssum

def get_mass_core(r,rho):
    ssum = rho[0]*r[0]**3/r[-1]**3
    for i in range(1,len(r)):
        ssum = ssum + rho[i]*(r[i]**3-r[i-1]**3)
    return ssum
    
def get_moi(r,rho,rho_mean):   
	# calculate moment of inertia given radius and density profiles.
    ssum = rho[0]/rho_mean*r[0]**5/r[-1]**5
    for i in range(1,len(r)):
        ssum = ssum + rho[i]/rho_mean*(r[i]**5/r[-1]**5-r[i-1]**5/r[-1]**5)

    return 2/5*ssum

def get_ccc(r,rho,rho_mean):
    ssum = rho[0]/rho_mean*r[0]**5/r[-1]**5
    for i in range(1,len(r)-2):
        ssum = ssum + rho[i]/rho_mean*(r[i]**5/r[-1]**5-r[i-1]**5/r[-1]**5)
    return 2/5*ssum

# Osolete
def getmelt_anzellini(chis,P,param,To):
    """
    Determines melting temperature of FeS mixture as a function 
    of chis and P.  
    Here, the melting point of pure Fe is determined according to Anzellini,
    Science 2013
    
    From Eq 2 of Anzellini et al 2013
    but reformulated as a 3rd order polynomial
    """

    el = param['li_el']
    
    if el == 'S':
        P1=P*1e-9;  
        # parametrization for Anzellini
        TmFe= 495.4969600595926*(22.19 + P1)**0.42016806722689076
        
        if P1 < 14:
            Te0=1265.4
            b1=-11.15
            Pe0=3
        elif P1 < 21:   
            Te0=1142.7
            b1=29
            Pe0=14
        else:    
            Te0=1345.72
            b1=12.9975
            Pe0=21
            
        Te=Te0+b1*(P1-Pe0)
        chiSeut=0.11+0.187*np.exp(-0.065*P1)
        
        Tm = TmFe -(TmFe - Te)*chis/chiSeut
        
        return Tm-To
    
    else:
        #a = 10
        #c = 3
        #P=P*1e-9
        #T0 = 1678 - 1000*chis
        #Tm = T0*(P/a+1)**(1/c)
        #return Tm-To   

        # Simon Glatzel Fit to Anzellini 
        #a = 22.19
        #c = 2.38
        #P=P*1e-9
        #T0 = 1822 - 1000*chis
        #Tm = T0*(P/a+1)**(1/c)
        #return Tm-To   
        
        P1=P*1e-9;  
        # parametrization for Anzellini
        TmFe= 495.4969600595926*(22.19 + P1)**0.42016806722689076
        Tm15 = 1478 *(P1/10+1)**(1/3)        
        Tm =(chis/0.15)*Tm15+(1-chis/0.15)*TmFe
        return Tm-To

# Osolete
def getmelt_anzellini_mix(el1, el2, P,To):
    """
    Determines melting temperature of FeS mixture as a function 
    of chis and P.  
    Here, the melting point of pure Fe is determined according to Anzellini,
    Science 2013
    
    From Eq 2 of Anzellini et al 2013
    but reformulated as a 3rd order polynomial
    """

    chis1 = el1/(1-el2)
    chis2 = el2/(1-el1)
    w1 = el1/(el1+el2)
    w2 = el2/(el1+el2)
    
    print(el1,chis1,el2,chis2)
    P1=P*1e-9 
    # parametrization for Anzellini
    TmFe= 495.4969600595926*(22.19 + P1)**0.42016806722689076
    
    if P1 < 14:
        Te0=1265.4
        b1=-11.15
        Pe0=3
    elif P1 < 21:   
        Te0=1142.7
        b1=29
        Pe0=14
    else:    
        Te0=1345.72
        b1=12.9975
        Pe0=21
        
    Te=Te0+b1*(P1-Pe0)
    chiSeut=0.11+0.187*np.exp(-0.065*P1)
    
    Tm1 = TmFe -(TmFe - Te)*chis1/chiSeut

    
    # parametrization for Anzellini
    TmFe= 495.4969600595926*(22.19 + P1)**0.42016806722689076
    Tm15 = 1478 *(P1/10+1)**(1/3)        
    Tm2 =(chis2/0.15)*Tm15+(1-chis2/0.15)*TmFe
    return (w1*Tm1+w2*Tm2)
